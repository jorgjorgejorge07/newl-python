# mi_libreria/modulo.py
def funcion_importante():
    return "¡Hola desde mi librería!"
