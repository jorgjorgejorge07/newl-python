# mi_libreria/__init__.py
from .modulo import funcion_importante
