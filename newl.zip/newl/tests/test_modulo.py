# tests/test_modulo.py
import unittest
from mi_libreria import funcion_importante

class TestMiLibreria(unittest.TestCase):
    def test_funcion_importante(self):
        self.assertEqual(funcion_importante(), "¡Hola desde mi librería!")

if __name__ == "__main__":
    unittest.main()
